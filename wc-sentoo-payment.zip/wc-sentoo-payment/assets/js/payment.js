jQuery(document).ready(function($) {

    $('#woocommerce_sentoo_payment_verify_btn').val('Verify');

    if($('#woocommerce_sentoo_payment_is_verify').val() == 'yes'){
        $('#woocommerce_sentoo_payment_verify_btn').val('Verified');
        $('#woocommerce_sentoo_payment_verify_btn').attr('disabled','disabled');
    }

    $('#woocommerce_sentoo_payment_verify_btn').on('click', function(e){
        e.preventDefault();
        $('#woocommerce_sentoo_payment_merchant_code').next("span").remove();
        var merchant_code = $('#woocommerce_sentoo_payment_merchant_code').val();
        var wp_nonce = $('#woocommerce_sentoo_payment_wp_nonce').val();
        jQuery.ajax({
            type: 'post',
            dataType: 'json',
            url: my_ajax_object.ajax_url,
            data: {
                merchant_code: merchant_code,
                wp_nonce: wp_nonce,
                action: 'get_verify_user'
            },
            success: function(response){
                console.log(response.message);
                if(response.status == true) {
                    $('#woocommerce_sentoo_payment_is_verify').val('yes');
                    validation(response);
                    $("#woocommerce_sentoo_payment_enabled").prop('checked', true);
                    if($('#woocommerce_sentoo_payment_is_verify').val() == 'yes'){
                        $('#woocommerce_sentoo_payment_verify_btn').val('Verified');
                        $('#woocommerce_sentoo_payment_verify_btn').attr('disabled','disabled');
                    }
                }else{
                    validation(response);
                    $('#woocommerce_sentoo_payment_merchant_code').val('');
                    $('#woocommerce_sentoo_payment_is_verify').val('no');
                    $("#woocommerce_sentoo_payment_enabled").prop('checked', false);
                }
            }
        });
    });

    $('#clearLog').on('click', function(e){
        jQuery.ajax({
            type: 'GET',
            dataType: 'json',
            url: my_ajax_object.ajax_url,
            data: {
                action:'clear_log_file'
            },
            success: function(response){
                console.log(response.message);
            }
        });
    });

    $("#mainform").submit(function() {
        var merchant_code = $('#woocommerce_sentoo_payment_merchant_code').val();
        if (merchant_code.length == 0) {
            if($('#merchant_code_validate').length > 0){
                $('#merchant_code_validate').remove();
            }
            validation('');
            return false;
        } else {
            return true;
        }
    });

    function validation(response){
        var style = '';
        var message = '';
        if(response.status){
            console.log(response);
            if(response.status == true){
                style = "margin-top: 5px;display: block;color: green;font-weight: bold;";
            }else{
                style = "margin-top: 5px;display: block;color: red;font-weight: bold;";
            }
            message = response.message;
        }else{
            if(response.status == false){
                style = "margin-top: 5px;display: block;color: red;font-weight: bold;";
                message = response.message;
            }else{ 
                style = "margin-top: 5px;display: block;color: red;font-weight: bold;";
                message = 'Merchant code is required.';
            }
        }
        if($('#merchant_code_validate').length > 0){
            $('#merchant_code_validate').remove();
        }
        $('#woocommerce_sentoo_payment_merchant_code').after('<div id="merchant_code_validate" style="'+style+'"> '+message+' </div>');
        return false;
    }

    $("#woocommerce_sentoo_payment_rateConversion").on("keypress keyup blur",function (e) {
        $(this).val($(this).val().replace(/[^0-9\.]/g,''));
        if ((e.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
            event.preventDefault();
        }
    });

    $('#woocommerce_sentoo_payment_rateConversion').attr('maxlength', 5);

});
