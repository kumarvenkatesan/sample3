<?php
/**
 * WooCommerce Sentoopay Plugin.
 *
 * @class       WC_Sentoopay
 **/

namespace App\Setting;
 
final class SentoopayController {
	/**
	 * @var plugin name
	 */
	public $name = 'WooCommerce Gateway Sentoo';

	/**
	 * @var plugin version
	 */
	public $version = '1.0.0';

	/**
	 * @var Singleton The reference the *Singleton* instance of this class
	 */
	protected static $_instance = null;

	/**
	 * @var plugin settings
	 */
	protected static $settings = null;

	public static $log = false;

	/**
	 * Returns the *Singleton* instance of this class.
	 *
	 * @return Singleton The *Singleton* instance.
	 */
	public static function get_instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Private clone method to prevent cloning of the instance of the
	 * *Singleton* instance.
	 *
	 * @return void
	 */
	private function __clone() {}

	/**
	 * Private unserialize method to prevent unserializing of the *Singleton*
	 * instance.
	 *
	 * @return void
	 */
	private function __wakeup() {}

	/**
	 * Protected constructor to prevent creating a new instance of the
	 * *Singleton* via the `new` operator from outside of this class.
	 */
	private function __construct() {
		$this->define_constants();
		$this->includes();
		$this->register_hooks();
	}

	/**
	 * Define constants
	 */
	private function define_constants() {
		define( 'WC_SENTOO_PAY_DIR', plugin_dir_path( WC_SENTOO_PLUGIN_FILE ) );
		define( 'WC_SENTOO_PAY_URL', plugin_dir_url( WC_SENTOO_PLUGIN_FILE ) );
		define( 'WC_SENTOO_PAY_BASENAME', plugin_basename( WC_SENTOO_PLUGIN_FILE ) );
		define( 'WC_SENTOO_PAY_VERSION', $this->version );
		define( 'WC_SENTOO_PAY_NAME', $this->name );
	}
	

	/**
	 * Include plugin dependency files
	 */
	private function includes() {
		require dirname(__FILE__) .'/class-wc-gateway-sentoopay.php';
	}

	/**
	 * Register hooks
	 */
	private function register_hooks() {
		add_action( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ), 0 );
	}

	/**
	 * Add the gateways to WooCommerce.
	 */
	public function add_gateway( $methods ) {
		$methods[] = 'WC_Gateway_Custom';
		return $methods;
	}
}
