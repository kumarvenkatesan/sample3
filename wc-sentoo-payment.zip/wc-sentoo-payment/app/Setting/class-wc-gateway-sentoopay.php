<?php

    class WC_Gateway_Custom extends WC_Payment_Gateway
    {
        public $domain;
        public $merchantCode;
        public $secretToken;
        public $uniqueMerchantId;
        public $instructions;
        public $isVerify;
        public $verifyBtn;
        public $redirectUrl;
        public $environment;
        public $currency;
        public $rateConversion;
        public $timezone;

        /**
         * Constructor for the gateway.
         */
        public function __construct()
        {
            $this->domain = 'sentoo_payment';

            // Setup properties
            $this->setup_properties();

            // Load the input field on the wp-admin.
            $this->init_form_fields();

            // Load the settings.
            $this->init_settings();

            // Define user set variables
            $this->title 				= $this->get_option('title');
            $this->merchantCode 		= $this->get_option('merchant_code');
            $this->description   		= $this->get_option('description');
            $this->secretToken   		= $this->get_option('secret_token');
            $this->uniqueMerchantId     = $this->get_option('unique_merchant_id');
            $this->instructions  		= $this->get_option('instructions', $this->description);
            $this->verifyBtn  			= $this->get_option('verify_btn');
            $this->isVerify  			= $this->get_option('is_verify');
            $this->redirectUrl   		= $this->get_option('redirect_url');
            $this->environment   		= $this->get_option('environment');
            $this->currency   		    = $this->get_option('currency');
            $this->rateConversion       = $this->get_option('rateConversion');
            $this->timezone             = $this->get_option('timezone');

            if ($this->isVerify == 'yes') {
                $this->enabled = 'yes';
            } else {
                $this->enabled = 'no';
            }

            // Actions
            add_action('woocommerce_update_options_payment_gateways_'.$this->id,
            array($this, 'process_admin_options'));
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));

            // Customer Emails
            add_action('woocommerce_email_before_order_table', array($this, 'email_instructions'), 10, 3);

            // load scripts and css
            add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
        }

        protected function setup_properties()
        {
            $this->id                 = 'sentoo_payment';
            $this->has_fields         = false;
            $this->order_button_text  = __('Pay with Sentoo', 'woocommerce-sentoo-payments');
            $this->method_title       = 'Sentoo payment';
            $this->method_description = __('Allows payments with sentoo gateway.', $this->domain);
        }

        /**
         * Initialise Gateway Settings Form Fields.
         */
        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => __('Enable/Disable', $this->domain),
                    'type'    => 'checkbox',
                    'label'   => __('Enable Sentoo Payment', $this->domain),
                ),
                'environment' => array(
                    'title'   => __('Environment', $this->domain),
                    'type'    => 'select',
                    'label'   => __('Set Environment', $this->domain),
                    'options' => array('live'=>"Live",'sandbox'=>"Sandbox"),
                    'default' => 'live'
                ),
                'currency' => array(
                    'title'         => __('Select Currency', $this->domain),
                    'type'          => 'select',
                    'label'         => __('', $this->domain),
                    'options'       => array('ANG'=>"ANG", 'USD'=>"USD", 'AWG'=>"AWG", 'EUR'=>"EUR", 'XCD'=>"XCD"),
                    'default'       => 'ANG',
                    'description'   => __('Select currency same as your merchant dashboard.',
                    $this->domain),
                   'desc_tip'       => true,
                ),
                'timezone' => array(
                    'title'   => __('Select Timezone', $this->domain),
                    'type'    => 'select',
                    'description' => __('Select timezone same as your merchant dashboard.',
                     $this->domain),
                    'desc_tip'    => true,
                    'label'   => __('', $this->domain),
                    'options' => array(
                                'America/Curacao'  => "America/Curacao",
                                'America/Chicago'  => "America/Chicago",
                                'Asia/Kolkata'     => "Asia/Kolkata",
                                'Europe/London'    => "Europe/London",
                                'Europe/Amsterdam' => "Europe/Amsterdam"
                            ),
                    'default' => 'America/Curacao'
                ),
                'rateConversion' => array(
                    'title'       => __('Rate Conversion', $this->domain),
                    'type'        => 'text',
                    'description' => __('Rate coversion of USD.', $this->domain),
                    'desc_tip'    => true,
                    'default'     => __('1', $this->domain),
                    'required'    => true,
                    'input_attrs' => array(
                        'maxlength' => 20
                    )
                ),
                'title' => array(
                    'title'       => __('Title', $this->domain),
                    'type'        => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', $this->domain),
                    'default'     => __(' Sentoo (through CX Pay)', $this->domain),
                    'desc_tip'    => true,
                    'required'    => true,
                ),
                'description' => array(
                    'title'       => __( 'Description:', 'woocommerce-sentoo-payments' ),
                    'type'        => 'textarea',
                    'description' => __('Description of Sentoo Payment Gateway that users sees on Checkout page.',
                    'woocommerce-sentoo-payments'),
                    'default'     => __( 'Pay securely with sentoo.', 'woocommerce-sentoo-payments' ),
                    'desc_tip'    => true
                ),
                'is_verify' => array(
                    'type'        => 'hidden',
                    'default' => 'no'
                ),
                'wp_nonce' => array(
                    'type'        => 'hidden',
                    'default' => wp_create_nonce('custom-action')
                ),
                'merchant_code' => array(
                    'title'       => __('Merchant Code', $this->domain),
                    'type'        => 'text',
                    'description' => __('Enter valid merchant code.', $this->domain),
                    'placeholder'   => __('Enter Merchant Code'),
                    'required'    => true,
                    'default'     => __('', $this->domain),
                    'desc_tip'    => true
                ),
                'verify_btn' => array(
                    'type' => 'button',
                    'default'  => 'Verify',
                    'class' => 'btn btn-primary',
                    'id'	=> 'activate'
                ),
                'secret_token' => array(
                    'title'       => __('Merchant secret', $this->domain),
                    'type'        => 'text',
                    'description' => __('Merchant secret from your sentoo account.', $this->domain),
                    'default'     => __('', $this->domain),
                    'desc_tip'    => true,
                    'required'    => true
                ),
                'unique_merchant_id' => array(
                    'title'       => __('Merchant ID', $this->domain),
                    'type'        => 'text',
                    'description' => __('Merchant ID from your sentoo account.', $this->domain),
                    'default'     => __('', $this->domain),
                    'desc_tip'    => true,
                    'required'    => true
                ),
                'debug' => array(
                    'title'       => __( 'Download Log', 'woocommerce-sentoo-payments' ),
                    'type'        => 'checkbox',
                    'label'       => 'Download request/response log of each transaction (text file download)',
                    'class' 	  => 'download-log-file',
                    'description' => __('
                    Download log file. <a href="'.home_url(
                        'wp-content/uploads/sentoo-logs/payment-log.txt')
                    .'" download> Download Log </a> <button id="clearLog"> Clear Log </button>'),
                    'default'     => 'no',
                ),
            );
        }

        /**
         * Output for the order received page.
         */
        public function thankyou_page()
        {
            if ($this->instructions) {
                echo wpautop(wptexturize($this->instructions));
            }
        }

        /**
         * Add content to the WC emails.
         *
         * @access public
         * @param WC_Order $order
         * @param bool $sent_to_admin
         * @param bool $plain_text
         */
        public function email_instructions($order, $sent_to_admin, $plain_text = false)
        {
            if ($this->instructions && !$sent_to_admin
            && 'custom' === $order->payment_method && $order->has_status('on-hold')) {
                echo wpautop(wptexturize($this->instructions)) . PHP_EOL;
            }
        }

        /**
         *  Payment field on the front-side
         */
        public function payment_fields()
        {
            if ($description = $this->get_description()) {
                echo wpautop(wptexturize($description));
            }
        }

        /**
         * Process the payment and return the result.
         *
         * @param int $orderId
         * @return array
         */
        public function process_payment($orderId)
        {
            global $wpdb, $woocommerce;

            $customerOrder = new WC_Order( $orderId );

            $tablename = $wpdb->prefix.'transaction_details';

            date_default_timezone_set($this->timezone);
            
            $astTime = date(DATEFORMAT);

            $expiredDate = get_post_meta($orderId, '_expired_date', true);

            $transactionId = get_post_meta($orderId, '_transaction_id', true);
            
            $paymentUrl = get_post_meta($orderId, '_payment_url', true);
            
            if ($expiredDate >= $astTime) {
                $merchantId = $this->uniqueMerchantId;
                $secretToken = $this->secretToken;

                if ($this->environment == 'sandbox') {
                    $transactionUrl = SENTOO_SANDBOX_API_URL."/payment/status/".$merchantId.'/'.$transactionId;
                } else {
                    $transactionUrl = SENTOO_API_URL."/payment/status/".$merchantId.'/'.$transactionId;
                }
        
                $getTransactions = sentooApiCall($transactionUrl, $secretToken);
                
                $getTransaction = json_decode($getTransactions, true);
                
                if ($getTransaction['success']['message'] == 'cancelled' ||
                     $getTransaction['success']['message'] == 'expired') {
                    $transactionFinalUrl = $this->transactionUrl($wpdb, $tablename, $customerOrder, $orderId);
                    return array('result' => 'success', 'redirect' => $transactionFinalUrl);
                } else {
                    return array('result' => 'success', 'redirect' => $paymentUrl);
                }
            } else {
                $transactionFinalUrl = $this->transactionUrl($wpdb, $tablename, $customerOrder, $orderId);
                return array('result' => 'success', 'redirect' => $transactionFinalUrl);
            }
        }
        
        /**
         * Payment_scripts function.
         *
         * Outputs styles/scripts used for stcpay payment
         *
         */
        public function payment_scripts()
        {
            // Register style for the front-end dispaly the css
            wp_register_style('sentoo-pay-frontend', WC_SENTOO_PAY_URL . '/assets/css/frontend.css',
                array(), WC_SENTOO_PAY_VERSION );
            wp_enqueue_style( 'sentoo-pay-frontend' );
        }

        public function transactionUrl($wpdb, $tablename, $customerOrder, $orderId)
        {
            // Get session data
            $sessionCustomer = WC()->session->get('customer');
            $sessionEmailLength = strlen($sessionCustomer['email']);
            
            if ($sessionEmailLength < 50){
                $sentooCustomer = $sessionCustomer['email'];
            } else {
                $sentooCustomer = '';
            }

            $sentooMerchant = $this->uniqueMerchantId;
            $wpCurrency = $this->currency;

            if ($this->rateConversion > 1) {
                $sentooAamount  = $customerOrder->order_total*$this->rateConversion;
                $sentooCurrency = $wpCurrency;
            } else {
                $sentooAamount  = $customerOrder->order_total;
                $sentooCurrency = $wpCurrency;
            }

            $sentooDescription = 'Order ID : '.$orderId;
            $callBackUrl = home_url().'/?wc-api=webhook_status%26orderId='.$orderId.'%26';

            if ($this->environment == 'sandbox') {
                $url = SENTOO_SANDBOX_API_URL."/payment/new";
            } else {
                $url = SENTOO_API_URL."/payment/new";
            }

            date_default_timezone_set($this->timezone);
            $expiredTime = date(DATEFORMAT, strtotime('+1 hour'));
            
            $payments = array(
                'sentoo_merchant'       => $sentooMerchant,
                'sentoo_currency'       => $sentooCurrency,
                'sentoo_amount'         => $sentooAamount * 100,
                'sentoo_description'    => $sentooDescription,
                'sentoo_return_url'     => $callBackUrl,
                'sentoo_customer'       => $sentooCustomer,
                'sentoo_expires'        => $expiredTime
            );

            $paymentData = '';
            foreach ($payments as $key => $value) {
                $paymentData .= $key . "=" . $value . "&";
            }

            $headers =  array(
                'accept' => 'application/json',
                'X-SENTOO-SECRET' => $this->secretToken,
                'Content-Type' => 'application/x-www-form-urlencoded'
            );
        
            $args = array(
                'method'      => 'POST',
                'timeout'     => 45,
                'sslverify'   => false,
                'headers'     => $headers,
                'body'        => $paymentData,
            );
            
            $requestData = wp_remote_post( $url, $args );

            $paymentResult = json_decode( $requestData['body'], true );

            $requestParameter = json_encode($payments);

            $typeRequest = 'Payment Request Response Parameter-----'
            ."\r\n".$requestParameter . "\r\n".json_encode($paymentResult);
            
            paymentLog( $typeRequest, 'a', 'payment-log');

            /**
             * Insert transaction details start
             */
            $merchantId = $this->merchantCode;
            $transactionId = $paymentResult['success']['message'];
            $paymentUrl = $paymentResult['success']['data']['url'];
            $paymentStatus = 'issued';
            $domainName = site_url();

            date_default_timezone_set($this->timezone);
            $currentDateTime = date(DATEFORMAT);
            
            if ($paymentResult['success']['code'] == 200) {
                update_post_meta($orderId, "_transaction_id", $transactionId);
                update_post_meta($orderId, "_order_id", $orderId);
                update_post_meta($orderId, "_payment_status", $paymentStatus);
                update_post_meta($orderId, "_payment_url", $paymentUrl);
                update_post_meta($orderId, "_return_url", $callBackUrl);
                update_post_meta($orderId, "_expired_date", $expiredTime);
                update_post_meta($orderId, "_created_date", $currentDateTime);
            }

            $transactionDetails = array(
                'merchant_id' => $merchantId,
                'transaction_id'=> $transactionId,
                'order_id'=> $orderId,
                'domain_name'=> $domainName,
                'payment_status' => $paymentStatus,
            );

            $trasactionResults = requestForTransaction(API_URL.'addTransaction', $transactionDetails);

            $addRequest = 'Add Transaction details -----'."\r\n".json_encode($trasactionResults);

            paymentLog( $addRequest, 'a', 'payment-log' );

            /**
             * Insert transaction details end
             */
            if ($paymentResult['success']['code'] == 200) {
                return $paymentResult['success']['data']['url'];
            } else {
                wc_add_notice($paymentResult['error']['message'], 'error');
            }
        }
    }