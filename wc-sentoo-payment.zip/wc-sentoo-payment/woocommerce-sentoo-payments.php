<?php

/**
 * Plugin Name: Sentoo Payment
 * Plugin URI:  https://cxpay.global/
 * Description: Sentoo's latest complete payments processing solution.
 * Version:     1.0.0
 * Author:      CX Pay
 * Author URI:  https://cxpay.global/
 * License:     GPL-2.0
 * Requires PHP: 7.1
 * WC requires at least: 3.9
 * WC tested up to: 7.0
 * Text Domain: woocommerce-sentoo-payments
 *
 * @package WooCommerce\SentooCommerce
 */

declare(strict_types=1);

require_once __DIR__ . '/vendor/autoload.php';
use App\Setting\SentoopayController;

if (!defined('ABSPATH')) {
	exit;
}

// Define base file
if (!defined('WC_SENTOO_PLUGIN_FILE')) {
	define('WC_SENTOO_PLUGIN_FILE', __FILE__);
}

define('SENTOO_API_URL', 'https://api.sentoo.io/v1');
define('SENTOO_SANDBOX_API_URL', 'https://api.sandbox.sentoo.io/v1');
define('API_URL', 'https://wpsentoo.cxpay.me/api/user/');
define('CHECKOUT_CUSTOM_TEXT', 'Checkout with custom payment.');
define('WC_SENTOO_MIN_WC_VER', '3.0');
define('CHECKOUT_CANCEL_CUSTOM_TEXT', 'Payment has been cancelled, please try again.');
if (!defined('DATEFORMAT')) {
	define('DATEFORMAT', 'Y-m-d H:i:s');
}

/**
 * Sentoo Payment Gateway.
 *
 * Provides a Sentoo Payment Gateway, mainly for testing purposes.
 */

(function() {
	/**
	 * Initialize the plugin and its modules.
	 */
	function sentoo_init()
	{
		$root_dir = __DIR__;
		
		if (!is_sentoo_woocommerce_activated()) {
			add_action(
				'admin_notices',
				function () {
					/* translators: 1. URL link. */
					echo '<div class="error"><p><strong>'.
					sprintf(esc_html__(
						'WooCommerce Sentoo Payments requires WooCommerce to be installed and active. You can download %s here.',
						'woocommerce-sentoo-payments'),
					'<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>').'</strong></p></div>';
				}
			);
			return;
		}

		if (defined('WC_VERSION') && version_compare(WC_VERSION, '3.0', '<')) {
			add_action('admin_notices', 'wc_sentoopay_version_wc_notice');
			return;
		}

		if (defined('PHP_VERSION') && version_compare(PHP_VERSION, '7.1', '<')) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="error"><p>';
					echo esc_html__('WooCommerce Sentoo Payments requires PHP 7.1 or above.', 'woocommerce-sentoo-payments');
					echo '</p></div>';
				}
			);
			return;
		}

		if (!class_exists('WC_Sentoopay')) {
			$sentooSettings = SentoopayController::get_instance();
			return $sentooSettings;
		}
	}

	add_action(
		'plugins_loaded',
		function () {
			sentoo_init();

			if (!function_exists('get_plugin_data')) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$pluginData = get_plugin_data(__DIR__ . '/woocommerce-sentoo-payments.php');
			
			$pluginVersion = $pluginData['Version'] ? $pluginData['Version'] : null;

			if (get_option('woocommerce-ppcp-version') !== $pluginVersion) {
				do_action('woocommerce_sentoo_payments_gateway_migrate');
				update_option('woocommerce-ppcp-version', $pluginVersion);
			}
		}
	);

	/**
	 * Activate plugin start
	*/
	register_activation_hook(
		__FILE__,
		function () {
			sentoo_init();
			clear_log_file();
			do_action('woocommerce_sentoo_payments_gateway_activate');
		}
	);

	/**
	 * Activate plugin end
	 */
	
	/**
	 * Deactivate plugin start
	 */
	register_deactivation_hook(
		__FILE__,
		function () {
			sentoo_init();
			do_action('woocommerce_sentoo_payments_gateway_deactivate');
		}
	);

	/**
	 * Deactvate plugin end
	 */

	// Add "Settings" link to Plugins screen.
	add_filter(
		'plugin_action_links_' . plugin_basename(__FILE__),
		function ($links) {
			if (!is_sentoo_woocommerce_activated()) {
				return $links;
			}
			array_unshift(
				$links,
				sprintf(
					'<a href="%1$s">%2$s</a>',
					admin_url('admin.php?page=wc-settings&tab=checkout&section=sentoo_payment'),
					__('Settings', 'woocommerce-sentoo-payments')
				)
			);
			return $links;
		}
	);

	/**
	 * Check if WooCommerce is active.
	 *
	 * @return bool true if WooCommerce is active, otherwise false.
	 */
	function is_sentoo_woocommerce_activated()
	{
		return class_exists('woocommerce');
	}

	//  Incdules custom scripts
	add_action('admin_menu', 'include_scripts');

	function include_scripts() {
		wp_register_script('my_plugin_script', plugins_url('assets/js/payment.js', __FILE__), array('jquery'));
		wp_enqueue_script('my_plugin_script');
		wp_enqueue_style('sentoo_style.css', plugins_url('/assets/css/sentoo_style.css', __FILE__), false, '1.0.0', 'all');
	}

	// Check verify merchant code
	function get_verify_user()
	{
		$siteUrl = site_url();
		$merchantCode = $_POST['merchant_code'];
		$verify = wp_verify_nonce($_POST['wp_nonce'], 'custom-action');

		if (!empty($merchantCode) && $verify == 1) {
			$paymentData = array(
				'merchant_code' => $merchantCode,
				'domain_name' 	=> $siteUrl
			);

			$headers = array('accept: application/json');
			$args = array(
                'method'      => 'POST',
                'timeout'     => 45,
                'sslverify'   => false,
                'headers'     => $headers,
                'body'        => $paymentData,
            );
            
			$requestData = wp_remote_post(API_URL.'/getVerifyUser', $args);

			if (!is_wp_error($requestData)) {
				$response = wp_remote_retrieve_body($requestData);
				if ($response) {
					$verifyResult = json_decode($response, true);
					return wp_send_json($verifyResult);
				}
			}
		} else {
			$result = array(
				'status'  => false,
				'message' => 'Enter merchant code...'
			);
			return wp_send_json($result);
		}
    }

	add_action('wp_ajax_nopriv_get_verify_user', 'get_verify_user');
	add_action('wp_ajax_get_verify_user', 'get_verify_user');

	// Clear log files start.
	function clear_log_file() {
		$uploadDir = wp_upload_dir();
		$dir = $uploadDir['basedir'].'/sentoo-logs/';
		$files = glob($dir . '/*');
		foreach ($files as $v) {
			unlink($v);
		}
		$filename = $uploadDir['basedir'].'/sentoo-logs/payment-log.txt';
		if (file_exists($filename)) {
			$fh = fopen($uploadDir['basedir'].'/sentoo-logs/payment-log.txt', 'w');
			fclose($fh);
		}
	}
	add_action( 'wp_ajax_nopriv_clear_log_file', 'clear_log_file' );
	add_action( 'wp_ajax_clear_log_file', 'clear_log_file' );
	// Clear log files end.

	function requestForTransaction($apiUrl, $paymentData)
	{
		$headers =  array(
			'accept' => 'application/json'
		);
	
		$args = array(
			'method'      => 'POST',
			'timeout'     => 45,
			'sslverify'   => false,
			'headers'     => $headers,
			'body'        => $paymentData
		);
		
		$requestData = wp_remote_post($apiUrl, $args);
		$response = json_decode($requestData['body'], true);
		if ($response) {
			return $response;
		}
	}

	function sentooApiCall($apiUrl, $headers)
	{
		$request = wp_remote_get($apiUrl, array(
					'timeout' => 10,
					'headers' => array(
						'accept' => 'application/json',
						'X-SENTOO-SECRET' => $headers,
						'Content-Type' => 'application/x-www-form-urlencoded'
					)
				)
			);

		if (!is_wp_error($request)) {
			$response = wp_remote_retrieve_body($request);
			if (is_wp_error($response) || !isset($response['body'])) {
				return $response;
			}
			return $response;
		}
	}
	
	// Generate log start
	function paymentLog( $entry, $mode = 'a', $file = 'plugin' )
	{
		// Get WordPress uploads directory.
		$uploadDir = wp_upload_dir();
		$uploadDir = $uploadDir['basedir'].'/sentoo-logs';
		if (!is_dir($uploadDir)) {
			mkdir($uploadDir, 0755, true);
		}
		// If the entry is array, json_encode.
		if (is_array($entry)) {
			$entry = json_encode( $entry );
		}
		// Write the log file.
		$file  = $uploadDir . '/' . $file . '.log';
		$file  = fopen( $file, $mode );
		$bytes = fwrite( $file, current_time( 'mysql' ) . "::" . $entry . "\n" );
		fclose( $file );
		return $bytes;
	}
	// Generate log end
	 
	// Load ajax script
	function loadScript() {
		wp_enqueue_script('ajax-script', plugins_url('assets/js/payment.js', __FILE__), array('jquery') );
		wp_localize_script('ajax-script', 'my_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
	}
	add_action('admin_enqueue_scripts', 'loadScript');
	add_action('wp_enqueue_scripts', 'loadScript');

	function filter_woocommerce_my_account_my_orders_actions( $actions, $order ) {
		// Get status
		$orderStatus = $order->get_status();
		// Status = cancelled
		if ($orderStatus == 'cancelled') {
			unset($actions['pay']);
		}
		// Status = completed
		if ($orderStatus == 'completed') {
			unset($actions['pay']);
		}
		// Status = pending
		if ($orderStatus == 'pending') {
			unset($actions['cancel']);
		}
		// Status = pending
		if ($orderStatus == 'on-hold') {
			unset($actions['pay']);
			unset($actions['cancel']);
		}
		if ($orderStatus == 'failed') {
			unset($actions['cancel']);
		}
		return $actions;
	}
	add_filter('woocommerce_my_account_my_orders_actions', 'filter_woocommerce_my_account_my_orders_actions', 10, 2);

	// Get post id using meta value
	function getPostIdFromMeta($metaKey, $metaValue) {
		global $wpdb;
		return $wpdb->get_var(
			$wpdb->prepare("
			SELECT post_id FROM 
			{$wpdb->prefix}postmeta WHERE meta_key = '%s'
			AND meta_value = '%s'", $metaKey, $metaValue ) );
	}

	/**
	 * Call webhook
	 */
	add_action('woocommerce_api_webhook_status', 'webhook');

	function webhook()
	{
		$webhookLog = 'check status by webhook for changes status by sentoo'.
		"\r\n".json_encode($_REQUEST)."\r\n".json_encode($_REQUEST);
		paymentLog($webhookLog, 'a', 'payment-log');

		if (isset($_REQUEST['orderId']) && !empty($_REQUEST['orderId'])) {
			$orderId = $_REQUEST['orderId'];
			$orderData = wc_get_order($orderId);
			if (empty($orderData)) {
				wp_redirect(home_url('/404page/'));
				exit;
			} else {
				$transactionId = get_post_meta($orderId, "_transaction_id", true);
				commonForGetTransactionDetail($orderId, $transactionId, "orderProcess");
			}
		} else {
			$transactionId = isset($_REQUEST['transaction_id']) ? $_REQUEST['transaction_id'] : '';
			if (!empty($transactionId)) {
				$orderId = getPostIdFromMeta('_transaction_id', $transactionId);
				commonForGetTransactionDetail($orderId, $transactionId, "webhook");
			} else {
				return wp_send_json_error();
			}
		}
	}
	
	/**
	 * Cron Function Start
	 */
	function getSentooTransaction($orderId, $transactionId) {
		$installedPaymentMethods = WC()->payment_gateways()->payment_gateways();
		$getPluginSetting = (array)$installedPaymentMethods['sentoo_payment'];
		
		if ($installedPaymentMethods['sentoo_payment']) {
			$secretToken = $getPluginSetting['settings']['secret_token'];
			$merchantId = $getPluginSetting['settings']['unique_merchant_id'];
			$environment = $getPluginSetting['settings']['environment'];
		}

		/* get transaction details start */
		if ($environment == 'live') {
			$transactionUrl = SENTOO_API_URL."/payment/status/".$merchantId.'/'.$transactionId;
		} else {
			$transactionUrl = SENTOO_SANDBOX_API_URL."/payment/status/".$merchantId.'/'.$transactionId;
		}

		$getTransactions = sentooApiCall($transactionUrl, $secretToken);
		
		$getTransaction = json_decode($getTransactions, true);

		$typeUpdateStatus = 'Get Transaction Call On Webhook -----';

		$getTransactionRequestParameter = array(
			'order_id' => $orderId,
			'merchant_id' => $merchantId,
			'TransactionId' => $transactionId,
			'enviroment' => $environment,
			'url' => $transactionUrl
		);
		
		$webhookLog = $typeUpdateStatus."\r\n".
		json_encode($getTransactionRequestParameter)."\r\n".json_encode($getTransaction);
		paymentLog($webhookLog, 'a', 'payment-log');
		return $getTransaction;
	}

	function commonForGetTransactionDetail($orderId, $transactionId, $orderType)
	{
		$getTransaction = getSentooTransaction($orderId, $transactionId);

		if ($getTransaction['success']['message']) {
		
			$updateUrl = API_URL.'updatePaymentStatus';
			
			$updateStatus = array(
				'order_id' => $orderId,
				'payment_status' => $getTransaction['success']['message'],
			);

			$updatePaymentStatus = requestForTransaction($updateUrl, $updateStatus);

			$typeUpdateStatus = 'Update Payment Status-----'."\r\n".json_encode($updateStatus).
			"\r\n".json_encode($updatePaymentStatus);

			paymentLog($typeUpdateStatus, 'a', 'payment-log');

			/**
			 * Fetch transaction status
			 */
			if ($getTransaction['success'] && $getTransaction['success']['data']['responses']) {
				foreach ($getTransaction['success']['data']['responses'] as $response) {
					$sentooPaymentStatus = $response['status'];
				}
			}

			$paymentStatusLog = 'payment-status-log'."\r\n".json_encode($sentooPaymentStatus).
			"\r\n".json_encode($sentooPaymentStatus);

			paymentLog($paymentStatusLog, 'a', 'payment-log');

			if ($getTransaction['success']['message'] == 'success' || $sentooPaymentStatus == 'success') {

				update_post_meta($orderId, '_payment_status', 'success');
				$updateUrl = API_URL.'updatePaymentStatus';
				$updateStatus = array(
					'order_id' => $orderId,
					'payment_status' => 'success',
				);
		
				$updatePaymentStatus = requestForTransaction($updateUrl, $updateStatus);
		
				$typeUpdateStatus = 'Success Payment Status-----'."\r\n".
				json_encode($updateStatus)."\r\n".json_encode($updatePaymentStatus);
		
				paymentLog($typeUpdateStatus, 'a', 'payment-log');
		
				//Assign the order ID using the $post->ID
				$order = new WC_Order($orderId);
				$order->update_status('completed', __(CHECKOUT_CUSTOM_TEXT, 'order_note'));
				// Remove cart
				WC()->cart->empty_cart();

				$orderRreceivedUrl = wc_get_endpoint_url( 'order-received', $order->get_id(), wc_get_checkout_url() );

				$orderSuccessUrl = add_query_arg( 'key', $order->get_order_key(), $orderRreceivedUrl );

				$updateUrl = API_URL.'updatePaymentStatus';
				
				$updateStatus = array(
					'order_id' => $orderId,
					'payment_status' => $getTransaction['success']['message'],
				);
		
				$updatePaymentStatus = requestForTransaction($updateUrl, $updateStatus);
		
				$paymentStatusLog = 'Complete Payment Status-----'."\r\n".
				json_encode($updateStatus)."\r\n".json_encode($updatePaymentStatus);
	
				paymentLog($paymentStatusLog, 'a', 'payment-log');
				
				if ($orderType == "orderProcess") {
					// Return success redirect
					return array(
						'result'    => 'success',
						'redirect'  => wp_redirect( $orderSuccessUrl )
					);
				} else {
					return wp_send_json_success();
				}

			} elseif ($getTransaction['success']['message'] == 'failed') {
				$paymentMessage = 'Payment has been failed.';
				setForRedirection($orderId, "failed", 'failed', $paymentMessage, $orderType);
			} elseif ($sentooPaymentStatus == 'cancelled') {
				$paymentMessage = CHECKOUT_CANCEL_CUSTOM_TEXT;
				setForRedirection($orderId, "cancelled", 'pending', $paymentMessage, $orderType);
			} elseif ($getTransaction['success']['message'] == 'pending') {
				$paymentMessage = 'Payment is being processed, we will update you when we receive a status update.';
				setForRedirection($orderId, "pending", 'on-hold', $paymentMessage, $orderType);
			} elseif ($sentooPaymentStatus == 'rejected') {
				$paymentMessage = 'Payment has been rejected, please try again.';
				setForRedirection($orderId, "rejected", 'pending', $paymentMessage, $orderType);
			} else {
				if ($getTransaction['success']['message'] == 'issued') {
					$paymentMessage = CHECKOUT_CANCEL_CUSTOM_TEXT;
					setForRedirection($orderId, "cancelled", 'pending', $paymentMessage, $orderType);
				} else {
					$order = wc_get_order($orderId);
					if (empty($order)) {
						wp_redirect(home_url('/404page/'));
						exit;
					}
					$updateUrl = API_URL.'updatePaymentStatus';
					
					$updateStatus = array(
						'order_id' => $orderId,
						'payment_status' => $getTransaction['success']['message'],
					);
		
					$updatePaymentStatus = requestForTransaction($updateUrl, $updateStatus);

					$paymentStatusLog = 'Cancel Payment Status-----'."\r\n".json_encode($updateStatus).
					"\r\n".json_encode($updatePaymentStatus);
	
					paymentLog($paymentStatusLog, 'a', 'payment-log');
		
					$order->update_status('pending', __(CHECKOUT_CUSTOM_TEXT, 'order_note'));
		
					wc_add_notice(__(CHECKOUT_CANCEL_CUSTOM_TEXT, 'gateway'), 'error');
					
					return wp_safe_redirect(wc_get_page_permalink('checkout'));
				}
			}
		}
	}

	function setForRedirection($orderId, $paymentStatus, $woocommerceStatus, $paymentMessage, $orderType) {
		$updateUrl = API_URL.'updatePaymentStatus';
		$updateStatus = array(
			'order_id' => $orderId,
			'payment_status' => $paymentStatus,
		);

		$updatePaymentStatus = requestForTransaction($updateUrl, $updateStatus);
		$paymentStatusLog = 'Update Payment Status-----'."\r\n".
		json_encode($updateStatus)."\r\n".json_encode($updatePaymentStatus);
			paymentLog($paymentStatusLog, 'a', 'payment-log');

		if ($paymentStatus) {
			update_post_meta($orderId, '_payment_status', $paymentStatus);
			$order = new WC_Order($orderId);
			$order->update_status($woocommerceStatus, __(CHECKOUT_CUSTOM_TEXT, 'order_note'));
			wc_add_notice(__($paymentMessage, 'gateway'), 'error');
			if ($orderType == 'orderProcess') {
				if ($paymentStatus == 'pending'){
					if ($order->order_key) {
						WC()->cart->empty_cart(false);
					}
				}
				$returnMessage = wp_safe_redirect(wc_get_page_permalink('checkout'));
			} else {
				$returnMessage = wp_send_json_success();
			}
		}
		return $returnMessage;
	}

	/**
	 * Cron Function End
	 */

	/**
	 * Update cart item start
	 */
	add_action('woocommerce_update_cart_action_cart_updated', 'on_action_cart_updated', 20, 1);
	
	function on_action_cart_updated()
	{
		updateRemoveCart();
	}

	/**
	 * Update cart item end
	 */

	/**
	 * Remove cart item start
	 */
	function remove_cart_updated()
	{
		updateRemoveCart();
	}
	
	add_action( 'woocommerce_remove_cart_item', 'remove_cart_updated', 10, 2 );
	/**
	 * Remove cart item end
	 */
	
	function updateRemoveCart() {

		global $woocommerce, $post, $wpdb;
		
		$installedPaymentMethods = WC()->payment_gateways()->payment_gateways();
		$getPluginSetting = (array)$installedPaymentMethods['sentoo_payment'];
		if ($installedPaymentMethods['sentoo_payment']) {
			$secretToken = $getPluginSetting['settings']['secret_token'];
			$merchantId  = $getPluginSetting['settings']['unique_merchant_id'];
			$environment = $getPluginSetting['settings']['environment'];
		}

		$orderId = $woocommerce->session->order_awaiting_payment;
		
		if (!empty($orderId)) {

			$transactionId = get_post_meta($orderId, "_transaction_id", true);
	
			if ($environment == 'live') {
				$transactionUrl = SENTOO_API_URL."/payment/cancel/".$merchantId.'/'.$transactionId;
			} else {
				$transactionUrl = SENTOO_SANDBOX_API_URL."/payment/cancel/".$merchantId.'/'.$transactionId;
			}

			$getTransactions = sentooApiCall($transactionUrl, $secretToken);

			$getTransaction = json_decode($getTransactions, true);

			$typeUpdateStatus = 'Cancel Transaction details :-'.$orderId.'-'.$transactionId;

			$getTransactionRequestParameter = array(
				'order_id' => $orderId,
				'merchant_id' => $merchantId,
				'TransactionId' => $transactionId,
				'enviroment' => $environment,
				'url' => $transactionUrl
			);
			$paymentStatusLogs = $typeUpdateStatus."\r\n".json_encode($getTransactionRequestParameter).
			"\r\n".json_encode($getTransaction);
			
			paymentLog($paymentStatusLogs, 'a', 'payment-log');
		}
	}

})();
